# ISDA CDM&trade; Generated Java Usage Examples

This project demonstrates functionality of the generated code artifacts of the ISDA Common Domain Model&trade; 

## Dependencies

Code dependencies can be found on the CDM Portal [here](https://portal.cdm.rosetta-technology.io/#/).  For access to the CDM Portal, please register [here](https://portal.cdm.rosetta-technology.io/#/register).

### Maven
A `settings.xml` file is provided in the project root directory, use it install dependencies as below: 
```bash
mvn -s settings.xml clean install

```
